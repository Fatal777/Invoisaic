/**
 * Webhook Handler - E-commerce Platform Integration
 *
 * This Lambda receives webhooks from e-commerce platforms and triggers
 * the autonomous agent to watch and act on purchases automatically
 *
 * Supported Platforms:
 * - Stripe
 * - Shopify
 * - WooCommerce
 * - Razorpay
 * - Square
 * - PayPal
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=webhookHandler.d.ts.map