import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Demo Lambda Handler - For hackathon demo
 * Simulates invoice generation with full AI reasoning
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=demoHandler.d.ts.map