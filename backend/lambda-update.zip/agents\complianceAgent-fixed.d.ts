/**
 * Compliance Agent - Ensures tax and regulatory compliance
 * Uses Amazon Nova Micro for compliance validation
 */
export declare class ComplianceAgent {
    private client;
    private modelId;
    constructor();
    /**
     * Validate invoice compliance across jurisdictions
     */
    validateCompliance(invoiceData: any, jurisdiction: string): Promise<any>;
    private buildCompliancePrompt;
    private parseComplianceResponse;
}
//# sourceMappingURL=complianceAgent-fixed.d.ts.map