/**
 * Customer Intelligence Agent - Analyzes payment patterns and behavior
 * Uses Amazon Nova Micro for predictive analytics
 */
export declare class CustomerIntelligenceAgent {
    private client;
    private modelId;
    constructor();
    /**
     * Analyze customer payment behavior and predict payment likelihood
     */
    analyzeCustomerBehavior(customerId: string, customerHistory: any): Promise<any>;
    /**
     * Predict payment probability and optimal timing
     */
    predictPaymentBehavior(customerId: string, invoiceAmount: number, customerHistory: any): Promise<any>;
    /**
     * Calculate customer lifetime value and relationship health
     */
    assessCustomerValue(customerId: string, customerData: any): Promise<any>;
    /**
     * Recommend optimal invoice timing based on customer behavior
     */
    recommendInvoiceTiming(customerId: string, customerHistory: any): Promise<any>;
    private buildBehaviorAnalysisPrompt;
    private parseBehaviorResponse;
    private parsePaymentPredictionResponse;
    private parseCustomerValueResponse;
    private parseTimingResponse;
}
//# sourceMappingURL=customerIntelligenceAgent.d.ts.map