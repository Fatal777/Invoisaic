import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Advanced Features Lambda Handler
 * Handles: Bulk generation, validation, OCR, reconciliation, product categorization
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=featuresHandler.d.ts.map