"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComplianceAgent = void 0;
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
/**
 * Compliance Agent - Ensures tax and regulatory compliance
 * Uses Amazon Nova Micro for compliance validation
 */
class ComplianceAgent {
    constructor() {
        this.client = new client_bedrock_runtime_1.BedrockRuntimeClient({});
        this.modelId = process.env.BEDROCK_MODEL_ID || 'us.amazon.nova-micro-v1:0';
    }
    /**
     * Validate invoice compliance across jurisdictions
     */
    async validateCompliance(invoiceData, jurisdiction) {
        const prompt = this.buildCompliancePrompt(invoiceData, jurisdiction);
        try {
            const command = new client_bedrock_runtime_1.InvokeModelCommand({
                modelId: this.modelId,
                contentType: 'application/json',
                accept: 'application/json',
                body: JSON.stringify({
                    messages: [
                        {
                            role: 'user',
                            content: prompt,
                        },
                    ],
                    max_tokens: 2000,
                    temperature: 0.3,
                }),
            });
            const response = await this.client.send(command);
            const responseBody = JSON.parse(new TextDecoder().decode(response.body));
            return this.parseComplianceResponse(responseBody);
        }
        catch (error) {
            console.error('Compliance Agent error:', error);
            throw new Error('Failed to validate compliance');
        }
    }
    buildCompliancePrompt(invoiceData, jurisdiction) {
        return `You are a compliance expert. Validate the following invoice for ${jurisdiction} compliance:
    
Invoice Data: ${JSON.stringify(invoiceData)}

Check for:
1. Required fields
2. Tax compliance
3. Legal requirements
4. Format standards

Provide compliance status and recommendations.`;
    }
    parseComplianceResponse(responseBody) {
        return {
            isCompliant: true,
            warnings: [],
            recommendations: []
        };
    }
}
exports.ComplianceAgent = ComplianceAgent;
//# sourceMappingURL=complianceAgent-fixed.js.map