/**
 * Semantic Search Handler using Titan Embeddings and Knowledge Base
 * Provides AI-powered search across invoices, customers, and tax knowledge
 */
export declare const handler: (event: any) => Promise<{
    statusCode: number;
    headers: {
        'Content-Type': string;
        'Access-Control-Allow-Origin': string;
        'Access-Control-Allow-Headers': string;
        'Access-Control-Allow-Methods': string;
    };
    body: string;
}>;
//# sourceMappingURL=searchHandler.d.ts.map