"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
const client = new client_dynamodb_1.DynamoDBClient({ region: process.env.REGION || process.env.AWS_REGION || 'ap-south-1' });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const tableName = process.env.DYNAMODB_CUSTOMERS_TABLE || 'invoisaic-customers';
const handler = async (event) => {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    };
    try {
        const { httpMethod, pathParameters, queryStringParameters, body } = event;
        if (httpMethod === 'OPTIONS') {
            return { statusCode: 200, headers, body: '' };
        }
        switch (httpMethod) {
            case 'GET':
                if (pathParameters?.id) {
                    return await getCustomer(pathParameters.id, headers);
                }
                else {
                    return await listCustomers(queryStringParameters || {}, headers);
                }
            case 'POST':
                return await createCustomer(JSON.parse(body || '{}'), headers);
            case 'PUT':
                return await updateCustomer(pathParameters?.id || '', JSON.parse(body || '{}'), headers);
            case 'DELETE':
                return await deleteCustomer(pathParameters?.id || '', headers);
            default:
                return {
                    statusCode: 405,
                    headers,
                    body: JSON.stringify({ error: 'Method not allowed' }),
                };
        }
    }
    catch (error) {
        console.error('Customer handler error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error.message,
            }),
        };
    }
};
exports.handler = handler;
async function createCustomer(data, headers) {
    const customerId = (0, uuid_1.v4)();
    const timestamp = new Date().toISOString();
    const customer = {
        id: customerId,
        ...data,
        totalInvoices: 0,
        totalRevenue: 0,
        averagePaymentDays: 0,
        riskScore: 50,
        createdAt: timestamp,
        updatedAt: timestamp,
    };
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: tableName,
        Item: customer,
    }));
    return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
            success: true,
            data: customer,
            message: 'Customer created successfully',
        }),
    };
}
async function getCustomer(id, headers) {
    const result = await docClient.send(new lib_dynamodb_1.GetCommand({
        TableName: tableName,
        Key: { id },
    }));
    if (!result.Item) {
        return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ error: 'Customer not found' }),
        };
    }
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            data: result.Item,
        }),
    };
}
async function listCustomers(params, headers) {
    const result = await docClient.send(new lib_dynamodb_1.ScanCommand({
        TableName: tableName,
        Limit: parseInt(params.pageSize || '20'),
    }));
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            items: result.Items || [],
            total: result.Count || 0,
            page: parseInt(params.page || '1'),
            pageSize: parseInt(params.pageSize || '20'),
            hasMore: !!result.LastEvaluatedKey,
        }),
    };
}
async function updateCustomer(id, data, headers) {
    const timestamp = new Date().toISOString();
    const result = await docClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: tableName,
        Key: { id },
        UpdateExpression: 'set #data = :data, updatedAt = :timestamp',
        ExpressionAttributeNames: {
            '#data': 'data',
        },
        ExpressionAttributeValues: {
            ':data': data,
            ':timestamp': timestamp,
        },
        ReturnValues: 'ALL_NEW',
    }));
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            data: result.Attributes,
            message: 'Customer updated successfully',
        }),
    };
}
async function deleteCustomer(id, headers) {
    await docClient.send(new lib_dynamodb_1.DeleteCommand({
        TableName: tableName,
        Key: { id },
    }));
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            message: 'Customer deleted successfully',
        }),
    };
}
//# sourceMappingURL=customerHandler.js.map