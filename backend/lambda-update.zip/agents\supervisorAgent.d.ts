/**
 * Supervisor Agent - Coordinates multi-agent workflows
 * Simplified version without Bedrock Agents API
 */
export declare class SupervisorAgent {
    private client;
    constructor();
    /**
     * Orchestrate the invoice processing workflow
     */
    orchestrateWorkflow(invoiceData: any): Promise<any>;
    /**
     * Make coordination decision combining all agent results
     */
    makeCoordinationDecision(pricingAnalysis: any, complianceCheck: any, customerInsights: any): Promise<any>;
    /**
     * Get agent status
     */
    getAgentStatus(): Promise<any>;
}
//# sourceMappingURL=supervisorAgent.d.ts.map