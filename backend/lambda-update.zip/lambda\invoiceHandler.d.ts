import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * API Gateway Lambda handler for invoice operations
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=invoiceHandler.d.ts.map