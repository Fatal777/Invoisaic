/**
 * Autonomous Agent Orchestrator
 *
 * This is the BRAIN of the system - makes intelligent decisions autonomously
 * Not just automation - true agentic intelligence
 */
interface DecisionContext {
    type: 'invoice_generation' | 'fraud_check' | 'tax_optimization' | 'compliance_validation';
    data: any;
    urgency: 'low' | 'medium' | 'high' | 'critical';
    confidence_required: number;
}
interface AgentDecision {
    action: string;
    reasoning: string;
    confidence: number;
    model_used: string;
    execution_time_ms: number;
    knowledge_base_queries: number;
    proactive_insights: string[];
    recommended_next_steps: string[];
    enhancements?: {
        textract_used: boolean;
        sagemaker_used: boolean;
        textract_confidence: number | null;
        ml_predictions: any | null;
    };
}
export declare class AutonomousOrchestrator {
    private knowledgeBaseId;
    private agentId;
    private decisionHistory;
    constructor();
    /**
     * STEP 1: AUTONOMOUS DECISION MAKING
     * Agent analyzes context and decides what to do (not just follows script)
     */
    makeAutonomousDecision(context: DecisionContext): Promise<AgentDecision>;
    /**
     * STEP 2: ASSESS COMPLEXITY (Decides which AI model to use)
     * Simple → Nova Micro (fast, cheap)
     * Complex → Nova Pro (reasoning)
     * Very Complex → Claude 3.5 Sonnet (deep analysis)
     */
    private assessComplexity;
    /**
     * STEP 3: SELECT OPTIMAL MODEL (Multi-model intelligence routing)
     */
    private selectOptimalModel;
    /**
     * STEP 4: QUERY KNOWLEDGE BASE (Real-time RAG - not hardcoded rules)
     */
    private queryKnowledgeBase;
    /**
     * Generate smart queries for Knowledge Base
     */
    private generateKnowledgeQueries;
    /**
     * STEP 5: ANALYZE HISTORICAL PATTERNS (Self-learning)
     */
    private analyzeHistoricalPatterns;
    /**
     * STEP 6: EXECUTE DECISION (Using selected model + all context)
     */
    private executeDecision;
    /**
     * Build intelligent prompt with all context
     */
    private buildIntelligentPrompt;
    /**
     * Parse AI response into structured decision
     */
    private parseAIDecision;
    /**
     * STEP 7: GENERATE PROACTIVE INSIGHTS (Predict issues before they happen)
     */
    private generateProactiveInsights;
    /**
     * STEP 8: STORE DECISION FOR LEARNING (Self-improving system)
     */
    private storeDecisionForLearning;
    /**
     * Helper: Get historical data
     */
    private getHistoricalData;
    /**
     * Helper: Extract common issues from historical data
     */
    private extractCommonIssues;
    /**
     * Helper: Calculate success rate
     */
    private calculateSuccessRate;
    /**
     * Helper: Extract action from text
     */
    private extractAction;
    /**
     * Helper: Extract confidence from text
     */
    private extractConfidence;
    /**
     * TEXTRACT INTEGRATION - Extract data from uploaded documents
     */
    processDocumentWithTextract(s3Key: string): Promise<any>;
    /**
     * SAGEMAKER INTEGRATION - Get ML predictions
     */
    getSageMakerPredictions(invoiceData: any, customerHistory: any): Promise<any>;
    /**
     * ENHANCED DECISION MAKING - Uses Textract + SageMaker
     */
    makeEnhancedDecision(context: DecisionContext, documentS3Key?: string, customerHistory?: any): Promise<AgentDecision>;
}
export default AutonomousOrchestrator;
//# sourceMappingURL=autonomousOrchestrator.d.ts.map