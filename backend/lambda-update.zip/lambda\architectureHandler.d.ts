/**
 * Architecture Handler
 *
 * API endpoints for Architecture View
 * Provides AWS infrastructure metrics, costs, and health status
 *
 * Routes:
 * GET /architecture/summary - Complete architecture overview
 * GET /architecture/services - All AWS services
 * GET /architecture/services/:serviceId - Specific service details
 * GET /architecture/cost - Cost analysis and comparison
 * GET /architecture/health - System health status
 */
export declare const handler: (event: any) => Promise<any>;
//# sourceMappingURL=architectureHandler.d.ts.map