/**
 * Agent Status Handler
 *
 * API endpoints for Agent Theater and real-time agent status
 *
 * Routes:
 * GET /agents/status - Get all agent statuses
 * GET /agents/status/:agentId - Get specific agent status
 * POST /agents/simulate - Simulate agent workflow (for demos)
 * POST /agents/reset - Reset all agents to idle
 * GET /agents/activity - Get activity summary
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const handler: (event: any) => Promise<any>;
/**
 * Streaming handler for real-time agent updates (WebSocket alternative)
 */
export declare const streamHandler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=agentStatusHandler.d.ts.map