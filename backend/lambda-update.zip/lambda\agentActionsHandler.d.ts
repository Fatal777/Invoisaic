/**
 * Bedrock Agent Action Group Handler
 * This Lambda is invoked by the Bedrock Agent to perform actions
 */
export declare const handler: (event: any) => Promise<{
    statusCode: number;
    body: any;
}>;
//# sourceMappingURL=agentActionsHandler.d.ts.map