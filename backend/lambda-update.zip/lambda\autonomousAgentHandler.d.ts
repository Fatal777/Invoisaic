/**
 * Autonomous Agent Lambda Handler
 *
 * This demonstrates REAL agentic AI in action:
 * - Autonomous decision-making
 * - Real-time Knowledge Base RAG
 * - Multi-model intelligence routing
 * - Self-learning from patterns
 * - Proactive risk prediction
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=autonomousAgentHandler.d.ts.map