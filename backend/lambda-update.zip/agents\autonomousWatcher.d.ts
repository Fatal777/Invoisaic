/**
 * Autonomous Purchase Watcher Agent
 *
 * THIS IS TRUE AGENTIC AI - Agent that monitors and acts independently
 *
 * How it works:
 * 1. Listens to e-commerce platform webhooks (Stripe, Shopify, WooCommerce)
 * 2. DETECTS purchases automatically (no human trigger)
 * 3. ANALYZES purchase context using AI vision + data
 * 4. DECIDES if invoice generation is needed
 * 5. GENERATES invoice autonomously
 * 6. VALIDATES compliance
 * 7. SENDS to customer automatically
 *
 * This is like having a virtual CFO working 24/7
 */
interface PurchaseEvent {
    platform: 'stripe' | 'shopify' | 'woocommerce' | 'square' | 'razorpay';
    event_type: string;
    transaction_id: string;
    amount: number;
    currency: string;
    customer: {
        email: string;
        name: string;
        country?: string;
        address?: any;
    };
    products: Array<{
        name: string;
        quantity: number;
        price: number;
        category?: string;
    }>;
    metadata?: any;
    timestamp: string;
    document_s3_key?: string;
    has_document?: boolean;
}
interface AutonomousDecision {
    should_generate_invoice: boolean;
    confidence: number;
    reasoning: string;
    invoice_data?: any;
    compliance_checks: string[];
    fraud_score: number;
    recommended_actions: string[];
}
export declare class AutonomousPurchaseWatcher {
    private orchestrator;
    constructor();
    /**
     * MAIN ENTRY POINT - Agent watches for purchase events
     * This gets triggered automatically by webhooks (no human intervention)
     */
    watchPurchase(event: PurchaseEvent): Promise<AutonomousDecision>;
    /**
     * Agent decides if this purchase needs action
     */
    private analyzeIfActionNeeded;
    /**
     * Agent gathers all context autonomously
     */
    private gatherAutonomousContext;
    /**
     * Autonomous fraud detection using patterns
     */
    private detectFraudAutonomously;
    /**
     * AI-powered fraud scoring
     */
    private getAIFraudScore;
    /**
     * Autonomous compliance validation
     */
    private validateComplianceAutonomously;
    /**
     * Generate invoice autonomously
     */
    private generateInvoiceAutonomously;
    /**
     * Notify customer autonomously
     */
    private notifyCustomerAutonomously;
    /**
     * Escalate to human when agent is unsure
     */
    private escalateToHuman;
    /**
     * Store decision for learning
     */
    private storeForLearning;
    private getCustomerHistory;
    private analyzeProducts;
    private determineJurisdiction;
    private findSimilarTransactions;
}
export default AutonomousPurchaseWatcher;
//# sourceMappingURL=autonomousWatcher.d.ts.map