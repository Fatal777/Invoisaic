/**
 * Pricing Agent - Handles complex pricing calculations
 * Uses Amazon Nova Micro for pricing intelligence
 */
export declare class PricingAgent {
    private client;
    private modelId;
    constructor();
    /**
     * Calculate optimal pricing with AI reasoning
     */
    calculatePricing(invoiceData: any, customerHistory: any): Promise<any>;
    /**
     * Calculate volume discounts using LLM reasoning
     */
    calculateVolumeDiscount(baseAmount: number, quantity: number, customerTier: string): Promise<any>;
    /**
     * Calculate early payment discount
     */
    calculateEarlyPaymentDiscount(amount: number, paymentTerms: string, customerReliability: number): Promise<any>;
    private buildPricingPrompt;
    private parsePricingResponse;
    private parseDiscountResponse;
    private parseEarlyPaymentResponse;
}
//# sourceMappingURL=pricingAgent.d.ts.map