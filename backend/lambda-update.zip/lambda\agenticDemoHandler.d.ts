/**
 * Agentic Demo Handler - Invokes Real Bedrock Agent
 * This connects the frontend demo to the actual AWS Bedrock Agent
 */
export declare const handler: (event: any) => Promise<{
    statusCode: number;
    headers: any;
    body: string;
}>;
//# sourceMappingURL=agenticDemoHandler.d.ts.map