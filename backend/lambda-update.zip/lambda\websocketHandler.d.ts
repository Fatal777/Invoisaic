import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * WebSocket Handler for real-time invoice processing updates
 * Handles connection lifecycle and message routing
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
/**
 * Send message to a specific WebSocket client
 */
export declare function sendMessageToClient(connectionId: string, domainName: string, stage: string, message: any): Promise<void>;
/**
 * Broadcast message to all connected clients
 */
export declare function broadcastMessage(domainName: string, stage: string, message: any): Promise<void>;
//# sourceMappingURL=websocketHandler.d.ts.map